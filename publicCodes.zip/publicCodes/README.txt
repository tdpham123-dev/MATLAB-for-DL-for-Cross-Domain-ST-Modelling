"Deep Learning for Cross-Domain Spatial Transcriptomic Modelling of Tissue Repair"
=============================================================================
Author: Tuan D. Pham

1. OVERVIEW

This code accompanies the manuscript named above. The workflow combines
spatial graph aggregation, wound-stage supervision, dataset-identity
supervision and deep embedded clustering (DEC) to analyse spatial
transcriptomic representations of wound and tumour tissues.

The study examines spatial coherence, latent cluster separation, marker-score
concordance, dataset mixing and cluster occupancy. A local recurrence
inconsistency index (LRII) summarises dissimilarity between eligible spatial
neighbours within a selected cluster. Marker scoring, recurrence summaries
and single-cell reference projection are post hoc analyses.

The analyses describe jointly fitted tissue sections. They do not establish
held-out predictive performance, biological ground truth or clinical utility.

2. SOFTWARE REQUIREMENTS

The main workflow is implemented in MATLAB.

The published-comparator analyses additionally require a Python environment.
Versions reported in the manuscript are:
  - PyTorch 2.8.0
  - PyTorch Geometric 2.6.1
  - harmonypy 2.0.2


3. DATA SOURCES

Download the original data from NCBI Gene Expression Omnibus (GEO):

Spatial transcriptomics:
  GSE241124  Human cutaneous wound healing; 16 sections
  https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE241124

  GSE208253  Oral squamous cell carcinoma (OSCC); 12 sections
  https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE208253

  GSE181300  Head and neck squamous cell carcinoma (HNSCC); 8 sections
  https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE181300

Single-cell references:
  GSE215403
  https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE215403

  GSE181919
  https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE181919

Gene-identifier harmonisation uses the human GRCh38 release 109 GTF annotation
from Ensembl. Preserve the source annotation version when reproducing the
analysis. Observe the original data providers' access and reuse conditions.

The spatial analysis includes 36 sections and 64,378 spots. Raw datasets
should be obtained from their original repositories rather than assumed to
be included with this code.

4. MAIN FILES

Workflow entry points:
  main_STmodeling.m                 Main MATLAB workflow
  run_ablation_studies.m            Training-component comparison workflow
  runSingleModelMode.m              Individual model-mode execution

Data preparation:
  loadAllSpatialSamples.m           Spatial sample loading
  buildSamples_GSE241124.m          Wound dataset preparation
  buildSamples_GSE208253.m          OSCC dataset preparation
  buildSamples_GSE181300.m          HNSCC dataset preparation
  harmoniseGenes.m                  Common gene alignment
  selectHighlyVariableGenesWithMarkers.m
                                   Feature selection with marker retention
  normaliseAndStandardise.m         Expression preprocessing

Model fitting and inference:
  initializeParameters.m            Parameter initialisation
  trainModel.m                      Model training
  inferEmbeddingsAndClusters.m      Embeddings and cluster assignment

Evaluation and reference analysis:
  computeAllMetrics.m               Evaluation summaries
  computeLocalCoherence.m           Spatial neighbour coherence
  computeDomainMixingPerSpot.m      Dataset mixing
  recurrenceMatrix.m               Recurrence-style similarity calculations
  computePathwayScores.m            Marker-expression summaries
  buildReference_GSE215403.m        Single-cell reference preparation
  buildReference_GSE181919.m        Single-cell reference preparation
  projectAllCellStates.m            Reference-signature projection workflow
  export_published_comparator_inputs.m
                                   Input export for external comparators

Retain all helper functions called by these workflows. Function filenames
containing SSI or "pathological cluster" reflect implementation terminology;
interpret their outputs using the definitions and cautions in the manuscript.


5. RUNNING THE WORKFLOW

1. Download or clone this repository and open MATLAB in its code directory.
   Add the code directory and any required helper subdirectories to the
   MATLAB path.

2. Download the datasets and Ensembl annotation listed above. Set the input
   and output paths in the main workflow and dataset preparation scripts to
   match your local installation. Replace machine-specific absolute paths.

3. Check the dataset-specific builders for the required count, gene,
   barcode, coordinate and metadata inputs. Preserve the section identities,
   spot ordering and gene ordering used across the analysis.

4. Use main_STmodeling.m as the starting point for the main analysis, then
   run the ablation workflow using run_ablation_studies.m. Inspect the entry
   points for required arguments, configuration settings and prerequisites.

5. Export the comparator inputs with export_published_comparator_inputs.m
   and run the accompanying STAGATE and Harmony scripts according to their
   supplied instructions. Their preprocessing differs as described below.

6. Run the final manuscript-output workflow to generate the evaluation
   summaries and figures from the saved results.


6. SETTINGS FOR THE REPORTED ANALYSIS

Use the manuscript configuration to reproduce the reported results:

  - 1,015 retained genes, aligned identically across sections.
  - Count normalisation to 10,000 followed by a log(1 + x) transformation,
    using totals over the retained genes.
  - Guarded gene-wise standardisation based on the four labelled wound
    sections; apply the same reference scale to the other sections.
  - Separate six-nearest-neighbour spatial graphs for each section, with
    no graph edges between sections.
  - Five global clusters and fitting seeds 1, 2 and 3.
  - 64-dimensional embeddings for the main model and original comparisons.
  - Main model training: 100 epochs, Adam learning rate 0.001; activate DEC
    after 20 warm-up epochs.
  - Stage supervision only for the four donor-4 wound sections corresponding
    to intact skin, day 1, day 7 and day 30.
  - Four ablations removing graph aggregation, wound-stage supervision,
    dataset-identity supervision or the DEC objective separately.

STAGATE uses log-normalised counts without wound-referenced standardisation,
a 30-dimensional embedding and 1,000 training epochs. Harmony uses pooled
64-component PCA inputs, with dataset identity as the correction variable.
Consult the manuscript and released configurations for all remaining settings.

7. OUTPUTS AND INTERPRETATION

The reported outputs include embeddings, cluster assignments, spatial maps,
marker scores, reference-signature summaries and section-level comparisons.
Evaluation includes latent silhouette, marker-score silhouette, local
coherence, dataset mixing, LRII and occupied-cluster counts.

Silhouette evaluation uses the same subset of at most 1,000 spots per section,
selected using seed 2718, across methods and fitting seeds. Section summaries
give eligible sections equal weight; undefined metrics must not be replaced
by zero. Paired comparisons use common eligible sections for each seed.

Reference-signature weights measure relative similarity, not cell fractions.
Spatial coherence can increase through smoothing. Dataset mixing and LRII
have no universal biological optimum. Results should be interpreted jointly
and within the limitations stated in the manuscript.

All sections contribute to fitting and descriptive evaluation. No section-
or donor-level holdout was performed. Exact numerical results may vary with
software versions, hardware and nondeterministic numerical operations.

