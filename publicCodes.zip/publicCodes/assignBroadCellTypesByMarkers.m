function labels = assignBroadCellTypesByMarkers(X, genes)

genes = upper(strtrim(string(genes)));

markerSets.Epithelial  = ["EPCAM","KRT5","KRT14","KRT19","KRT8","KRT18"];
markerSets.Fibroblast  = ["COL1A1","COL1A2","DCN","LUM","COL3A1","FAP"];
markerSets.Endothelial = ["PECAM1","VWF","KDR","FLT1","CLDN5"];
markerSets.Immune      = ["PTPRC","CD3D","CD3E","CD68","LYZ","MS4A1"];
markerSets.Stromal     = ["VIM","ACTA2","TAGLN","PDGFRB","RGS5"];

types = string(fieldnames(markerSets));
scoreMat = zeros(size(X,1), numel(types));

Xn = log1p(double(X));

for t = 1:numel(types)
    markers = markerSets.(types(t));
    [~, idx] = intersect(genes, markers, 'stable');

    if isempty(idx)
        scoreMat(:,t) = 0;
    else
        scoreMat(:,t) = mean(Xn(:,idx), 2, 'omitnan');
    end
end

[~, best] = max(scoreMat, [], 2);
labels = types(best);

end