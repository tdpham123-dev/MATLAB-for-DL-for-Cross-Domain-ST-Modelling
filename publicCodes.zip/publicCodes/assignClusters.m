function labels = assignClusters(Z, mu)

if isa(mu, 'dlarray')
    mu = gather(extractdata(mu));
end

Z = double(Z);
mu = double(mu);

n = size(Z,1);
K = size(mu,1);

dist2 = zeros(n,K);

for k = 1:K
    diff = Z - mu(k,:);
    dist2(:,k) = sum(diff.^2,2);
end

q = 1 ./ (1 + dist2);
q = q ./ (sum(q,2) + eps);

[~, labels] = max(q, [], 2);

end