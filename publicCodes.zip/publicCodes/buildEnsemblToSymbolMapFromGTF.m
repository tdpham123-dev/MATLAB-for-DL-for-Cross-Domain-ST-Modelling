function geneMap = buildEnsemblToSymbolMapFromGTF(gtfFile)
% Build Ensembl-to-HGNC mapping from a GTF file.
% Input:
%   gtfFile: e.g. Homo_sapiens.GRCh38.110.gtf
% Output:
%   geneMap table with EnsemblID and GeneSymbol

fid = fopen(gtfFile, 'r');
if fid < 0
    error('Cannot open GTF file: %s', gtfFile);
end

ensemblIDs = strings(0,1);
geneSymbols = strings(0,1);

while ~feof(fid)
    line = fgetl(fid);

    if startsWith(line, '#')
        continue;
    end

    parts = split(string(line), char(9));

    if numel(parts) < 9
        continue;
    end

    featureType = parts(3);

    if featureType ~= "gene"
        continue;
    end

    attr = parts(9);

    geneID = regexp(attr, 'gene_id "([^"]+)"', 'tokens', 'once');
    geneName = regexp(attr, 'gene_name "([^"]+)"', 'tokens', 'once');

    if ~isempty(geneID) && ~isempty(geneName)
        ensemblIDs(end+1,1) = erase(string(geneID{1}), regexp(string(geneID{1}), '\.\d+$', 'match', 'once'));
        geneSymbols(end+1,1) = upper(strtrim(string(geneName{1})));
    end
end

fclose(fid);

geneMap = table(ensemblIDs, geneSymbols, ...
    'VariableNames', {'EnsemblID','GeneSymbol'});

geneMap = unique(geneMap, 'rows');

save('ensembl_to_hgnc_geneMap.mat', 'geneMap');

fprintf('Saved mapping with %d genes.\n', height(geneMap));
end