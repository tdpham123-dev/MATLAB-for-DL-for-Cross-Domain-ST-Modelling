function ref = buildReference_GSE181919(folderPath)

countFile = fullfile(folderPath, 'GSE181919_UMI_counts.txt');
metaFile  = fullfile(folderPath, 'GSE181919_Barcode_metadata.txt');

if ~isfile(countFile)
    error('Missing file: %s', countFile);
end

T = readtable(countFile, 'FileType', 'text', 'ReadVariableNames', true);

genes = upper(strtrim(string(T{:,1})));
X = table2array(T(:,2:end))';

cellLabels = strings(size(X,1),1);

if isfile(metaFile)
    M = readtable(metaFile, 'FileType', 'text', 'ReadVariableNames', true);
    labelCol = find(contains(lower(M.Properties.VariableNames), ...
        ["celltype","cell_type","cluster","annotation"]), 1);

    if ~isempty(labelCol) && height(M) == size(X,1)
        cellLabels = upper(strtrim(string(M{:,labelCol})));
    end
end

if all(cellLabels == "")
    cellLabels = assignBroadCellTypesByMarkers(X, genes);
end

ref = makeCellReferenceFromLabels(X, genes, cellLabels, "GSE181919");

end