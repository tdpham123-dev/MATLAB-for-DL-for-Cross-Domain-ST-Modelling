function ref = buildReference_GSE215403(folderPath)

files = dir(fullfile(folderPath, '*_matrix.mtx'));

Xall = [];
geneList = [];

for i = 1:numel(files)

    prefix = erase(files(i).name, '_matrix.mtx');

    matrixFile = fullfile(folderPath, files(i).name);
    featureFile = fullfile(folderPath, prefix + "_features.tsv");

    if ~isfile(featureFile)
        warning('Missing feature file for %s', prefix);
        continue;
    end

    M = mmread(matrixFile)';
    F = readtable(featureFile, 'FileType', 'text', ...
        'Delimiter', '\t', 'ReadVariableNames', false);

    genes = upper(strtrim(string(F{:,2})));

    if isempty(Xall)
        Xall = M;
        geneList = genes;
    else
        [shared, ia, ib] = intersect(geneList, genes, 'stable');
        Xall = Xall(:, ia);
        M = M(:, ib);
        Xall = [Xall; M];
        geneList = shared;
    end
end

ref = makeSimpleCellReference(Xall, geneList, "GSE215403");

end