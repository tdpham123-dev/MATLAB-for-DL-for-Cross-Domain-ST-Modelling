function samples = buildSamples_GSE181300(basePath)
% GSE181300:
% Uses:
%   *_filtered_feature_bc_matrix.h5
%   *_tissue_positions_list.csv
%   *_scalefactors_json.json
% Ignores:
%   raw matrix, filtered mtx, barcodes/features tsv, web summary, images.

sampleIDs = {
    'GSM5494475_HNSCC201125T04'
    'GSM5494476_HNSCC201125T05'
    'GSM5494477_HNSCC201125T07'
    'GSM5494478_HNSCC201125T10'
    'GSM5494479_P210325T1'
    'GSM5494480_P210325T3'
    'GSM5494481_P210325T5'
    'GSM5494482_P210325T6'
};

samples = struct([]);

for i = 1:numel(sampleIDs)
    sid = sampleIDs{i};

    samples(i).dataset = "GSE181300";
    samples(i).domain = 3;
    samples(i).id = sid;
    samples(i).h5 = fullfile(basePath, sid + "_filtered_feature_bc_matrix.h5");
    samples(i).positions = fullfile(basePath, sid + "_tissue_positions_list.csv");
    samples(i).spatialFolder = "";
    samples(i).label = NaN;
end
end