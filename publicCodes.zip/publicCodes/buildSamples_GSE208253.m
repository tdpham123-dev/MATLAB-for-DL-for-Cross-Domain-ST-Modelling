function samples = buildSamples_GSE208253(basePath)
% GSE208253:
% Uses flat files:
%   GSM*_filtered_feature_bc_matrix.h5
%   GSM*_tissue_positions_list.csv
%   GSM*_scalefactors_json.json
% Images are ignored.

sampleIDs = {
    'GSM6339631_s1'
    'GSM6339632_s2'
    'GSM6339633_s3'
    'GSM6339634_s4'
    'GSM6339635_s5'
    'GSM6339636_s6'
    'GSM6339637_s7'
    'GSM6339638_s8'
    'GSM6339639_s9'
    'GSM6339640_s10'
    'GSM6339641_s11'
    'GSM6339642_s12'
};

samples = struct([]);

for i = 1:numel(sampleIDs)
    sid = sampleIDs{i};

    samples(i).dataset = "GSE208253";
    samples(i).domain = 2;
    samples(i).id = sid;
    samples(i).h5 = fullfile(basePath, sid + "_filtered_feature_bc_matrix.h5");
    samples(i).positions = fullfile(basePath, sid + "_tissue_positions_list.csv");
    samples(i).spatialFolder = "";
    samples(i).label = NaN;
end
end