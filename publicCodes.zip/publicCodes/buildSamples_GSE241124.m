function samples = buildSamples_GSE241124(basePath)
% GSE241124:
% Uses:
%   *_filtered_feature_bc_matrix.h5
%   matching *_spatial_images folder
%
% Labels:
%   Skin    = 0
%   Wound1  = 1
%   Wound7  = 2
%   Wound30 = 3
%   P17401/P20063 samples are unlabelled unless metadata is added.

h5Files = dir(fullfile(basePath, '*_filtered_feature_bc_matrix.h5'));

samples = struct([]);
count = 0;

for i = 1:numel(h5Files)

    fname = h5Files(i).name;
    gsmID = regexp(fname, 'GSM\d+', 'match', 'once');

    spatialDir = dir(fullfile(basePath, [gsmID '*_spatial_images']));

    if isempty(spatialDir)
        warning('No spatial folder found for %s. Skipping.', fname);
        continue;
    end

    count = count + 1;

    samples(count).dataset = "GSE241124";
    samples(count).domain = 1;
    samples(count).id = erase(fname, '_filtered_feature_bc_matrix.h5');
    samples(count).h5 = fullfile(h5Files(i).folder, fname);
    samples(count).spatialFolder = fullfile(spatialDir(1).folder, spatialDir(1).name);
    samples(count).positions = "";
    samples(count).label = NaN;

    if contains(fname, 'Skin')
        samples(count).label = 0;
    elseif contains(fname, 'Wound1')
        samples(count).label = 1;
    elseif contains(fname, 'Wound7')
        samples(count).label = 2;
    elseif contains(fname, 'Wound30')
        samples(count).label = 3;
    end
end
end