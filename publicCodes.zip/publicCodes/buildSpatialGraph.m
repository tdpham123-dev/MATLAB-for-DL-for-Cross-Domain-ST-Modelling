function Ahat = buildSpatialGraph(S, k)
% Build kNN spatial graph and normalized adjacency matrix.

[idx, dist] = knnsearch(S, S, 'K', k+1);
idx = idx(:,2:end);
dist = dist(:,2:end);

n = size(S,1);
sigmaS = median(dist(:));

rows = repmat((1:n)', k);
%rows = repmat((1:n)', k, 1);
cols = idx(:);
vals = exp(-(dist(:).^2) ./ (sigmaS^2 + eps));

A = sparse(rows, cols, vals, n, n);
A = max(A, A');          % symmetrize
A = A + speye(n);        % self-loops

deg = sum(A,2);
Dinv2 = spdiags(1 ./ sqrt(deg + eps), 0, n, n);

Ahat = Dinv2 * A * Dinv2;
end