function Ahat = buildSpatialGraph2(S, k)

S = double(S);
n = size(S,1);

% Faster kNN
Mdl = KDTreeSearcher(S);
[idx, dist] = knnsearch(Mdl, S, 'K', k+1);

idx = idx(:,2:end);
dist = dist(:,2:end);

sigmaS = median(dist(:));

rows = repmat((1:n)', k, 1);
cols = idx(:);
vals = exp(-(dist(:).^2) ./ (sigmaS^2 + eps));

A = sparse(rows, cols, vals, n, n);
A = max(A, A');
A = A + speye(n);

deg = sum(A,2);
Dinv2 = spdiags(1 ./ sqrt(deg + eps), 0, n, n);

Ahat = Dinv2 * A * Dinv2;

end