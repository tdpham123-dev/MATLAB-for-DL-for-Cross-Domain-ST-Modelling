function loss = clusteringLoss(Z, mu)

n = size(Z,1);
K = size(mu,1);

dist2 = dlarray(zeros(n,K,'single'));

for k = 1:K
    diff = Z - mu(k,:);
    dist2(:,k) = sum(diff.^2,2);
end

Q = (1 + dist2).^(-1);
Q = Q ./ sum(Q,2);

f = sum(Q,1);
P = (Q.^2) ./ f;
P = P ./ sum(P,2);

loss = mean(sum(P .* log((P + 1e-8) ./ (Q + 1e-8)),2));
end