function loss = clusteringLossDEC(Z, mu)
% clusteringLossDEC
% DEC clustering loss using Student t-distribution assignments.

n = size(Z,1);
K = size(mu,1);

dist2 = dlarray(zeros(n,K,'single'));

for k = 1:K
    diff = Z - mu(k,:);
    dist2(:,k) = sum(diff.^2, 2);
end

q = 1 ./ (1 + dist2);
q = q ./ (sum(q,2) + eps);

f = sum(q,1);
p = (q.^2) ./ (f + eps);
p = p ./ (sum(p,2) + eps);

% Detach target distribution from gradient calculation
p = dlarray(gather(extractdata(p)));

loss = mean(sum(p .* log((p + eps) ./ (q + eps)), 2));

end