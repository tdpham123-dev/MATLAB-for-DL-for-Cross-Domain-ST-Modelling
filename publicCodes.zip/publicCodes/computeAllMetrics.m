function metrics = computeAllMetrics(params, X, Ahat, labels, domains, Z, ...
    clusterLabels, localCoherence, PFI, SSIscore, settings)

sampleAccuracy = [];
sampleF1 = [];
sampleSensitivity = [];
sampleSpecificity = [];

for i = 1:numel(X)

    valid = ~isnan(labels{i});

    if any(valid)

        Zi = dlarray(single(Z{i}));
        logits = Zi * params.Wc + params.bc;
        probs = softmax(logits, 'DataFormat', 'BC');
        [~, pred] = max(extractdata(probs), [], 2);

        yTrue = labels{i}(valid) + 1;
        yPred = pred(valid);

        sampleAccuracy(end+1,1) = mean(yPred == yTrue);
        sampleF1(end+1,1) = macroF1Score(yTrue, yPred);

        [sens, spec] = multiclassSensitivitySpecificity(yTrue, yPred, settings.numStages);
        sampleSensitivity(end+1,1) = mean(sens, 'omitnan');
        sampleSpecificity(end+1,1) = mean(spec, 'omitnan');
    end
end

metrics.classification.accuracyMean = mean(sampleAccuracy, 'omitnan');
metrics.classification.accuracyStd = std(sampleAccuracy, 'omitnan');

metrics.classification.macroF1Mean = mean(sampleF1, 'omitnan');
metrics.classification.macroF1Std = std(sampleF1, 'omitnan');

metrics.classification.sensitivityMean = mean(sampleSensitivity, 'omitnan');
metrics.classification.sensitivityStd = std(sampleSensitivity, 'omitnan');

metrics.classification.specificityMean = mean(sampleSpecificity, 'omitnan');
metrics.classification.specificityStd = std(sampleSpecificity, 'omitnan');

sampleSil = nan(numel(Z),1);

for i = 1:numel(Z)
    try
        if numel(unique(clusterLabels{i})) > 1
            s = silhouette(Z{i}, clusterLabels{i});
            sampleSil(i) = mean(s, 'omitnan');
        end
    catch
        sampleSil(i) = NaN;
    end
end

metrics.clustering.silhouetteMean = mean(sampleSil, 'omitnan');
metrics.clustering.silhouetteStd = std(sampleSil, 'omitnan');
metrics.clustering.sampleSilhouette = sampleSil;

Zall = cat(1, Z{:});
domainVec = cat(1, domains{:});
domainMixVals = computeDomainMixingPerSpot(Zall, domainVec);

metrics.domain.domainMixingMean = mean(domainMixVals, 'omitnan');
metrics.domain.domainMixingStd = std(domainMixVals, 'omitnan');

metrics.spatial.localCoherenceMean = meanCellVector(localCoherence);
metrics.spatial.localCoherenceStd = stdCellVector(localCoherence);

metrics.spatial.PFIMean = mean(PFI, 'omitnan');
metrics.spatial.PFIStd = std(PFI, 'omitnan');

metrics.biological.SSIMean = meanCellVector(SSIscore);
metrics.biological.SSIStd = stdCellVector(SSIscore);

end