function entropyVals = computeDomainMixingPerSpot(Z, domainVec)
% computeDomainMixingPerSpot
% Computes local domain-mixing entropy for each spatial spot.
%
% Inputs:
%   Z         - all latent embeddings, spots x latent dimensions
%   domainVec - domain label for each spot
%
% Output:
%   entropyVals - local domain mixing score for each spot
%
% Interpretation:
%   Higher values indicate better mixing of datasets in latent space.

Z = double(Z);
domainVec = double(domainVec(:));

k = min(20, size(Z,1)-1);

if k < 1
    entropyVals = NaN(size(Z,1),1);
    return;
end

[idx, ~] = knnsearch(Z, Z, 'K', k+1);
idx = idx(:,2:end);

domains = unique(domainVec);
D = numel(domains);

entropyVals = zeros(size(Z,1),1);

for i = 1:size(Z,1)

    neighDomains = domainVec(idx(i,:));
    p = zeros(D,1);

    for d = 1:D
        p(d) = mean(neighDomains == domains(d));
    end

    entropyVals(i) = -sum(p .* log(p + eps)) / log(D + eps);
end

end