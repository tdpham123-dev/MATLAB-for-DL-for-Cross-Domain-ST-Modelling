function rho = computeLocalCoherence(R, S, k)

[idx, ~] = knnsearch(S, S, 'K', k+1);
idx = idx(:,2:end);

rho = zeros(size(S,1),1);

for i = 1:size(S,1)
    rho(i) = mean(R(i, idx(i,:)), 'omitnan');
end

end