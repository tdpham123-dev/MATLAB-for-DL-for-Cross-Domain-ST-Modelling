function PFI = computePFI(R, S, clusterLabels, pathologicalCluster, k)

[idx, ~] = knnsearch(S, S, 'K', k+1);
idx = idx(:,2:end);

vals = [];

for i = 1:size(S,1)
    if clusterLabels(i) == pathologicalCluster
        neigh = idx(i,:);
        neigh = neigh(clusterLabels(neigh) == pathologicalCluster);
        vals = [vals; R(i, neigh)'];
    end
end

if isempty(vals)
    PFI = NaN;
else
    PFI = 1 - mean(vals, 'omitnan');
end

end