function scores = computePathwayScores(X, geneSymbols)
% Compute pathway activity scores using HGNC gene symbols.
%
% Inputs:
%   X           - spots x genes expression matrix
%   geneSymbols - HGNC symbols corresponding to columns of X
%
% Output:
%   scores structure with one score vector per pathway

geneSymbols = upper(strtrim(string(geneSymbols)));

inflammationGenes = [
    "IL1B","TNF","CXCL8","CXCL1","CXCL2", ...
    "S100A8","S100A9","NFKBIA","PTGS2","CCL2"
];

hypoxiaGenes = [
    "HIF1A","VEGFA","CA9","LDHA","SLC2A1","ENO1","BNIP3"
];

ecmGenes = [
    "COL1A1","COL1A2","COL3A1","FN1","POSTN", ...
    "MMP2","MMP9","VIM","TIMP1"
];

osteogenesisGenes = [
    "RUNX2","SP7","ALPL","BGLAP","SPP1","IBSP","BMP2","BMP4"
];

angiogenesisGenes = [
    "VEGFA","KDR","FLT1","PECAM1","VWF","ANGPT1","ANGPT2"
];

scores.inflammation = meanGeneSet(X, geneSymbols, inflammationGenes);
scores.hypoxia      = meanGeneSet(X, geneSymbols, hypoxiaGenes);
scores.ecm          = meanGeneSet(X, geneSymbols, ecmGenes);
scores.osteogenesis = meanGeneSet(X, geneSymbols, osteogenesisGenes);
scores.angiogenesis = meanGeneSet(X, geneSymbols, angiogenesisGenes);

scores.detected.inflammation = intersect(geneSymbols, inflammationGenes);
scores.detected.hypoxia      = intersect(geneSymbols, hypoxiaGenes);
scores.detected.ecm          = intersect(geneSymbols, ecmGenes);
scores.detected.osteogenesis = intersect(geneSymbols, osteogenesisGenes);
scores.detected.angiogenesis = intersect(geneSymbols, angiogenesisGenes);

end