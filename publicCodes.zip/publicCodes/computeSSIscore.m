function SSI = computeSSIscore(scores)
% Composite SSI-like impaired-healing score.
%
% High SSI indicates inflammatory, hypoxic, matrix-remodelling,
% low-osteogenic tissue regions.

betaInflammation = 1.0;
betaHypoxia      = 1.0;
betaECM          = 1.0;
betaAngiogenesis = 0.5;
betaOsteogenesis = 1.0;

SSI = betaInflammation * zscoreSafe(scores.inflammation) + ...
      betaHypoxia      * zscoreSafe(scores.hypoxia) + ...
      betaECM          * zscoreSafe(scores.ecm) + ...
      betaAngiogenesis * zscoreSafe(scores.angiogenesis) - ...
      betaOsteogenesis * zscoreSafe(scores.osteogenesis);

end