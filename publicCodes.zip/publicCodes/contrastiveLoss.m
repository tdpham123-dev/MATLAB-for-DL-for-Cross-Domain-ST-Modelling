function loss = contrastiveLoss(Z)

Z = Z ./ sqrt(sum(Z.^2,2) + 1e-8);
simMat = Z * Z';

tau = 0.1;
n = size(Z,1);

% nearest latent neighbour as positive pair
largeNeg = dlarray(single(1e6));
simNoDiag = simMat - eye(n,'like',single(extractdata(simMat))) * largeNeg;

[~, posIdx] = max(extractdata(simNoDiag), [], 2);

loss = dlarray(0);

for i = 1:n
    numerator = exp(simMat(i,posIdx(i)) / tau);
    denominator = sum(exp(simMat(i,:) / tau));
    loss = loss - log(numerator / (denominator + 1e-8) + 1e-8);
end

loss = loss / n;
end