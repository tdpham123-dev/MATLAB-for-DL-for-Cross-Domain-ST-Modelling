function loss = crossEntropyLoss(logits, labels)
% labels must be 1, 2, ..., C

labels = double(labels(:));
C = size(logits,2);
n = numel(labels);

Y = zeros(n, C, 'single');
for i = 1:n
    Y(i, labels(i)) = 1;
end

Y = dlarray(Y);

P = softmax(logits, 'DataFormat', 'BC');
loss = -mean(sum(Y .* log(P + 1e-8), 2));
end