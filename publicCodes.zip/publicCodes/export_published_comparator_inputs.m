function archive = export_published_comparator_inputs(rootDir, spatialRoot)
% Export verified inputs for published-method comparisons; no retraining.
% archive = export_published_comparator_inputs(rootDir)
% Requires the original MATLAB1 functions and reviewer2_benchmark_outputs.
% Preserves the existing seven methods and three seeds without changing them.
if nargin<1, rootDir='D:\WORK\spatialBiology-Trauma\MATLAB1'; end
if nargin<2
    spatialRoot=fullfile(fileparts(rootDir),'spatialTranscriptomics');
end
addpath(rootDir);
bench=fullfile(rootDir,'reviewer2_benchmark_outputs');
protocolFile=fullfile(bench,'benchmark_protocol.mat');
modelFile=fullfile(bench,'FullModel_seed1.mat');
assert(isfile(protocolFile),'Missing protocol: %s',protocolFile);
assert(isfile(modelFile),'Missing seed-1 checkpoint: %s',modelFile);
P=load(protocolFile); Q=load(modelFile,'runResult'); R=Q.runResult;
assert(R.signature.seed==1 && string(R.signature.mode)=="FullModel");
assert(isequal(string(P.names(:)),string(R.signature.samples(:))));
assert(isequal(string(P.featureNames(:)),string(R.signature.features(:))));
assert(isequaln(P.scaleMean,R.signature.mean));
assert(isequaln(P.safeStd,R.signature.std));
assert(isequaln(P.evalIdx,R.signature.evalIdx));
assert(R.signature.settings.kGraph==6 && R.signature.settings.numClusters==5);
required=["buildSamples_GSE241124","buildSamples_GSE208253", ...
    "buildSamples_GSE181300","loadAllSpatialSamples","normalizeCounts", ...
    "forwardEncoder","computePathwayScores","computeSSIscore"];
for fn=required
    assert(~isempty(which(char(fn))),'Missing original function: %s',fn);
end
src=[buildSamples_GSE241124(fullfile(spatialRoot,'GSE241124','GSE241124_RAW')), ...
    buildSamples_GSE208253(fullfile(spatialRoot,'GSE208253','GSE208253_RAW')), ...
    buildSamples_GSE181300(fullfile(spatialRoot,'GSE181300','GSE181300_RAW'))];
[raw,coords,~,~,genes,names]=loadAllSpatialSamples(src);
names=string(names(:));
assert(numel(unique(names))==numel(names),'Duplicate section identifiers.');
[found,order]=ismember(string(P.names(:)),names);
assert(all(found),'A benchmark section is missing.');
raw=raw(order); coords=coords(order); genes=genes(order); names=names(order);
N=numel(names); counts=cell(N,1); scaled=cell(N,1);
markers=cell(N,1); scs=cell(N,1); neighbours=cell(N,1);
errors=zeros(N,1); sizes=zeros(N,1);
for i=1:N
    originalCounts=double(full(alignFeatures(raw{i},genes{i},P.featureNames)));
    counts{i}=single(originalCounts);
    assert(isequal(double(counts{i}),originalCounts), ...
        'Counts cannot be represented exactly as single precision.');
    x=double(normalizeCounts(originalCounts));
    scaled{i}=single((x-P.scaleMean)./P.safeStd);
    xy=double(coords{i}); z=double(R.Z{i}); sizes(i)=size(xy,1);
    assert(size(xy,2)==2 && sizes(i)==size(z,1));
    assert(all(isfinite(scaled{i}),'all') && all(isfinite(xy),'all'));
    [A,idx]=localGraph(xy); neighbours{i}=idx;
    rebuilt=forwardEncoder(R.params,scaled{i},A,R.signature.settings);
    if isa(rebuilt,'dlarray'), rebuilt=extractdata(rebuilt); end
    rebuilt=double(gather(rebuilt));
    errors(i)=max(abs(rebuilt-z),[],'all');
    assert(errors(i)<=1e-5*max(1,max(abs(z),[],'all')), ...
        'Embedding mismatch for %s: check data and preprocessing.',names(i));
    scores=computePathwayScores(scaled{i},P.symbols);
    markers{i}=[scores.inflammation,scores.hypoxia,scores.ecm, ...
        scores.angiogenesis,scores.osteogenesis];
    scs{i}=computeSSIscore(scores);
    fprintf('Verified %d/%d: %s\n',i,N,names(i));
end
clear raw genes Q rebuilt A x originalCounts

% Numeric arrays are saved separately from CSV identifiers for portability.
offsets=[0;cumsum(sizes)];
rawCounts=cat(1,counts{:}); Xscaled=cat(1,scaled{:});
coordinates=double(cat(1,coords{:})); markerScores=double(cat(1,markers{:}));
compositeScore=double(cat(1,scs{:}));
sectionIndex=zeros(offsets(end),1,'uint32');
datasetIndex=zeros(offsets(end),1,'uint32');
evaluationMask=false(offsets(end),1);
neighbourIndex=zeros(offsets(end),6,'uint32');
seed1Embedding=double(cat(1,R.Z{:}));
seed1Clusters=double(cat(1,R.clusters{:}));
for i=1:N
    rows=offsets(i)+(1:sizes(i));
    sectionIndex(rows)=i; datasetIndex(rows)=P.domain(i);
    evaluationMask(offsets(i)+P.evalIdx{i})=true;
    neighbourIndex(rows,:)=uint32(offsets(i)+neighbours{i});
end
scaleMean=double(P.scaleMean); safeStd=double(P.safeStd);
assert(size(rawCounts,2)==numel(P.featureNames));
assert(all(rawCounts>=0,'all') && all(rawCounts==round(rawCounts),'all'));

% Keep all existing results. Refuse incomplete or duplicate metric rows.
oldFile=fullfile(bench,'per_section_metrics.csv');
assert(isfile(oldFile),'Missing existing benchmark metrics: %s',oldFile);
existing=readtable(oldFile,'TextType','string');
modes=["PCA","GraphPCA","FullModel","NoGraph","NoStageLoss", ...
    "NoDomainLoss","NoClusteringLoss"];
for mode=modes
    for seed=1:3
        t=existing(existing.Model==mode & existing.Seed==seed,:);
        assert(height(t)==N && numel(unique(t.SampleID))==N, ...
            'Incomplete or duplicate rows for %s seed %d.',mode,seed);
        assert(all(ismember(names,t.SampleID)),'Section identifiers differ.');
    end
end
seedOne=existing(existing.Model=="FullModel" & existing.Seed==1,:);
[ok,loc]=ismember(string(R.perSection.SampleID),seedOne.SampleID);
assert(all(ok));
metricNames={'OccupiedClusters','LatentSilhouette','MarkerSilhouette', ...
    'DomainMixing','LocalCoherence','LRII','SelectedCluster', ...
    'EligibleDirectedPairs','Bandwidth'};
for j=1:numel(metricNames)
    a=double(R.perSection.(metricNames{j}));
    column=seedOne.(metricNames{j}); b=double(column(loc));
    assert(all((isnan(a)&isnan(b)) | abs(a-b)<=1e-8), ...
        'Saved CSV and seed-1 checkpoint differ in %s.',metricNames{j});
end
destination=fullfile(rootDir,'published_comparator_inputs');
archive=fullfile(rootDir,'published_comparator_inputs.zip');
assert(~isfolder(destination), ...
    'Destination already exists; rename it before making another export.');
assert(~isfile(archive),'Archive already exists; rename it before exporting.');
mkdir(destination);
save(fullfile(destination,'inputs.mat'),'rawCounts','Xscaled','coordinates', ...
    'markerScores','compositeScore','sectionIndex','datasetIndex', ...
    'evaluationMask','neighbourIndex','seed1Embedding','seed1Clusters', ...
    'scaleMean','safeStd','offsets','-v7.3');
sections=table((1:N)',names,double(P.domain(:)),double(P.stage(:)), ...
    sizes,offsets(1:end-1)+1,offsets(2:end),errors, ...
    'VariableNames',{'SectionIndex','SampleID','DatasetIndex','Stage', ...
    'Spots','FirstRowMATLAB','LastRowMATLAB','MaxEmbeddingError'});
writetable(sections,fullfile(destination,'sections.csv'));
writetable(table(string(P.featureNames(:)),string(P.symbols(:)), ...
    'VariableNames',{'Feature','Symbol'}),fullfile(destination,'features.csv'));
writetable(existing,fullfile(destination,'existing_per_section_metrics.csv'));
copyfile(protocolFile,fullfile(destination,'benchmark_protocol.mat'));
copyfile(modelFile,fullfile(destination,'FullModel_seed1.mat'));
copyfile([mfilename('fullpath') '.m'], ...
    fullfile(destination,'export_published_comparator_inputs.m'));
info=struct('exportedAt',char(datetime('now','TimeZone','UTC')), ...
    'purpose','Published comparator inputs; no new comparator results', ...
    'seeds',[1 2 3],'numClusters',5,'evaluationNeighbours',6, ...
    'matrixLayout','spots by features in MATLAB; MAT v7.3 HDF5 axes reverse in h5py', ...
    'indexing','MATLAB one-based indices; offsets start at zero', ...
    'expression','Raw retained-feature counts and guarded benchmark scaling', ...
    'sourceCheckpoint',modelFile,'sourceProtocol',protocolFile);
fid=fopen(fullfile(destination,'export_info.json'),'w');
assert(fid>=0); fcloseGuard=onCleanup(@()fclose(fid));
fprintf(fid,'%s',jsonencode(info,'PrettyPrint',true)); clear fcloseGuard
listing=dir(destination); listing=listing(~[listing.isdir]);
zip(archive,{listing.name},destination);
fprintf('\nUpload this verified archive:\n%s\n',archive);
end

function [A,idx]=localGraph(xy)
n=size(xy,1); assert(n>6 && size(unique(xy,'rows'),1)==n);
[idx,d]=knnsearch(xy,xy,'K',7); idx=idx(:,2:end); d=d(:,2:end);
sigma=median(d(:));
A=sparse(repmat((1:n)',6,1),idx(:),exp(-d(:).^2/(sigma^2+eps)),n,n);
A=max(A,A')+speye(n);
D=spdiags(1./sqrt(full(sum(A,2))+eps),0,n,n); A=D*A*D;
end

function X=alignFeatures(X,genes,features)
if istable(genes)
    ids=upper(strtrim(string(genes.GeneID(:))));
    if ismember('FeatureType',genes.Properties.VariableNames)
        valid=contains(lower(string(genes.FeatureType(:))),"gene");
    else, valid=true(size(ids)); end
else
    ids=upper(strtrim(string(genes(:)))); valid=true(size(ids));
end
keep=find(valid); [uniqueIDs,first]=unique(ids(valid),'stable');
[found,loc]=ismember(upper(strtrim(string(features(:)))),uniqueIDs);
assert(all(found),'A section lacks retained genes.');
X=X(:,keep(first(loc)));
end
