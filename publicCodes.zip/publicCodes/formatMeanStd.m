function txt = formatMeanStd(mu, sigma)
% formatMeanStd
% Formats mean and standard deviation for manuscript tables.
%
% Input:
%   mu    - mean value
%   sigma - standard deviation
%
% Output:
%   txt   - string in the form "mean ± SD"

if nargin < 2 || isnan(mu) || isempty(mu)
    txt = "NA";
    return;
end

if isnan(sigma) || isempty(sigma)
    txt = sprintf('%.3f', mu);
else
    txt = sprintf('%.3f ± %.3f', mu, sigma);
end

end