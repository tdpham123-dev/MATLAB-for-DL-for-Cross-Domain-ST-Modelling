function Z = forwardEncoder(params, X, Ahat, settings)

Xdl = dlarray(single(X));

if settings.useGraph
    A = dlarray(single(full(Ahat)));
    H1 = relu(A * Xdl * params.W1 + params.b1);
    H2 = relu(A * H1 * params.W2 + params.b2);
    Z = A * H2 * params.W3 + params.b3;
else
    H1 = relu(Xdl * params.W1 + params.b1);
    H2 = relu(H1 * params.W2 + params.b2);
    Z = H2 * params.W3 + params.b3;
end
end