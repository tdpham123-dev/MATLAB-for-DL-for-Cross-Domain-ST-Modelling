function Z = forwardEncoder1(params, X, Ahat)

Xdl = dlarray(single(X));
Afull = dlarray(single(full(Ahat)));

H1 = relu(Afull * Xdl * params.W1 + params.b1);
H2 = relu(Afull * H1 * params.W2 + params.b2);
Z = Afull * H2 * params.W3 + params.b3;
end