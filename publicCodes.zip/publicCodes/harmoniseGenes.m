function [Xout, commonGenes] = harmoniseGenes(X, geneLists)
% harmoniseGenes
% Harmonises genes across spatial transcriptomic datasets.
%
% Inputs:
%   X         - cell array of expression matrices, each spots x genes
%   geneLists - cell array of gene information tables from load10x_h5_counts
%
% Outputs:
%   Xout        - cell array of harmonised expression matrices
%   commonGenes - common gene symbols retained across all datasets
%
% Note:
%   This function uses gene symbols rather than Ensembl IDs so that
%   pathway scoring with marker genes such as IL1B, TNF, COL1A1, VEGFA,
%   RUNX2, and ALPL can be performed directly.

fprintf('\nChecking gene identifier overlap...\n');

useGeneSymbol = false;

Gsymbol = cell(size(geneLists));
Gid = cell(size(geneLists));
Xsym = cell(size(X));
Xid = cell(size(X));

for i = 1:numel(geneLists)

    gi = geneLists{i};

    if istable(gi)

        symbols = string(gi.GeneSymbol);
        ids = string(gi.GeneID);

        if any(strcmp(gi.Properties.VariableNames, 'FeatureType'))
            isGene = contains(lower(string(gi.FeatureType)), "gene");
        else
            isGene = true(size(symbols));
        end

    else

        symbols = string(gi);
        ids = string(gi);
        isGene = true(size(symbols));

    end

    symbols = upper(strtrim(symbols));
    ids = upper(strtrim(ids));

    valid = isGene & ...
            symbols ~= "" & ...
            ids ~= "" & ...
            symbols ~= "NA" & ...
            ids ~= "NA";

    Xi = X{i}(:, valid);
    symbols = symbols(valid);
    ids = ids(valid);

    % Remove duplicate gene symbols
    [symbolsUnique, iaSym] = unique(symbols, 'stable');
    Gsymbol{i} = symbolsUnique;
    Xsym{i} = Xi(:, iaSym);

    % Remove duplicate gene IDs
    [idsUnique, iaID] = unique(ids, 'stable');
    Gid{i} = idsUnique;
    Xid{i} = Xi(:, iaID);

end

% Common gene symbols
commonSymbol = Gsymbol{1};
for i = 2:numel(Gsymbol)
    commonSymbol = intersect(commonSymbol, Gsymbol{i}, 'stable');
end

% Common gene IDs
commonID = Gid{1};
for i = 2:numel(Gid)
    commonID = intersect(commonID, Gid{i}, 'stable');
end

fprintf('Common gene symbols: %d\n', numel(commonSymbol));
fprintf('Common gene IDs:     %d\n', numel(commonID));

if useGeneSymbol

    fprintf('Using GeneSymbol for harmonisation.\n');
    commonGenes = commonSymbol;
    G = Gsymbol;
    Xuse = Xsym;

else

    fprintf('Using GeneID for harmonisation.\n');
    commonGenes = commonID;
    G = Gid;
    Xuse = Xid;

end

if isempty(commonGenes)
    error(['No common genes found. Check whether datasets use compatible ', ...
           'gene identifiers or run inspectGeneIdentifiers(geneLists).']);
end

Xout = cell(size(Xuse));

for i = 1:numel(Xuse)

    [~, idx] = intersect(G{i}, commonGenes, 'stable');

    if numel(idx) ~= numel(commonGenes)
        warning('Sample %d has fewer matched genes than expected.', i);
    end

    Xout{i} = Xuse{i}(:, idx);

end

fprintf('Final harmonised genes retained: %d\n', numel(commonGenes));

% Optional marker-gene sanity check for biological scoring
markerCheck = ["IL1B","TNF","CXCL8","COL1A1","VEGFA","RUNX2","ALPL"];
detectedMarkers = intersect(commonGenes, markerCheck, 'stable');

fprintf('Detected pathway marker genes: ');
if isempty(detectedMarkers)
    fprintf('none\n');
    warning(['No pathway marker genes detected among commonGenes. ', ...
             'Pathway scoring may not be biologically meaningful.']);
else
    fprintf('%s\n', strjoin(detectedMarkers, ', '));
end

fprintf('\n');

end