function pathologicalCluster = identifyPathologicalClusterBySSI(clusterLabels, SSIscore)
% identifyPathologicalClusterBySSI
% Identifies the cluster with the highest mean SSI-like score.
%
% Inputs:
%   clusterLabels - cluster assignment for each spatial spot
%   SSIscore      - SSI-like score for each spatial spot
%
% Output:
%   pathologicalCluster - cluster ID with highest mean SSI-like score

clusters = unique(clusterLabels);
meanSSI = nan(numel(clusters),1);

for k = 1:numel(clusters)
    idx = clusterLabels == clusters(k);
    meanSSI(k) = mean(SSIscore(idx), 'omitnan');
end

[~, maxIdx] = max(meanSSI);
pathologicalCluster = clusters(maxIdx);

end