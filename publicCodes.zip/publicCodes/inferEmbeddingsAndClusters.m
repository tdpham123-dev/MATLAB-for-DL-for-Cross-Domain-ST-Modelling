function [Z, clusterLabels] = inferEmbeddingsAndClusters(params, X, Ahat, settings)
% Infer latent embeddings and assign spatial clusters.
%
% Inputs:
%   params   - trained model parameters
%   X        - cell array of expression matrices
%   Ahat     - cell array of graph adjacency matrices
%   settings - structure containing model settings
%
% Outputs:
%   Z             - cell array of latent embeddings
%   clusterLabels - cell array of cluster labels for each spatial spot

Z = cell(numel(X),1);
clusterLabels = cell(numel(X),1);

for i = 1:numel(X)

    % Forward pass through GNN or MLP encoder
    Zi = forwardEncoder(params, X{i}, Ahat{i}, settings);

    % Convert dlarray to numeric matrix
    Z{i} = gather(extractdata(Zi));

    % Cluster assignment
    if settings.useClusteringLoss
        clusterLabels{i} = assignClusters(Z{i}, params.mu);
    else
        clusterLabels{i} = kmeans(Z{i}, settings.numClusters, ...
            'Replicates', 10, ...
            'MaxIter', 1000);
    end
end

end