function params = initializeParameters(inputDim, hiddenDim1, hiddenDim2, latentDim, numStages, numDomains, numClusters)
% initializeParameters
% Initialises GNN/MLP encoder, classification head, domain head, and DEC centroids.

% Encoder
params.W1 = dlarray(single(randn(inputDim, hiddenDim1) * sqrt(2/inputDim)));
params.b1 = dlarray(single(zeros(1, hiddenDim1)));

params.W2 = dlarray(single(randn(hiddenDim1, hiddenDim2) * sqrt(2/hiddenDim1)));
params.b2 = dlarray(single(zeros(1, hiddenDim2)));

params.W3 = dlarray(single(randn(hiddenDim2, latentDim) * sqrt(2/hiddenDim2)));
params.b3 = dlarray(single(zeros(1, latentDim)));

% Classification head
params.Wc = dlarray(single(randn(latentDim, numStages) * 0.01));
params.bc = dlarray(single(zeros(1, numStages)));

% Domain classifier
params.Wd = dlarray(single(randn(latentDim, numDomains) * 0.01));
params.bd = dlarray(single(zeros(1, numDomains)));

% DEC clustering centroids
params.mu = dlarray(single(randn(numClusters, latentDim) * 0.01));

end