function inspectGeneIdentifiers(geneLists)

fprintf('\nGene identifier inspection\n');
fprintf('==========================\n');

for i = 1:numel(geneLists)

    gi = geneLists{i};

    if istable(gi)
        fprintf('\nSample %d\n', i);
        fprintf('Number of features: %d\n', height(gi));

        disp(head(gi, 10));

        if any(strcmp(gi.Properties.VariableNames, 'FeatureType'))
            disp(groupsummary(gi, 'FeatureType'));
        end
    else
        fprintf('\nSample %d\n', i);
        fprintf('Number of genes: %d\n', numel(gi));
        disp(gi(1:min(10,end)));
    end
end

end