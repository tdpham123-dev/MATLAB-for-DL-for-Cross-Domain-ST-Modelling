function reg = l2Penalty(params)

reg = dlarray(0);
fields = fieldnames(params);

for i = 1:numel(fields)
    val = params.(fields{i});
    reg = reg + sum(val(:).^2);
end
end