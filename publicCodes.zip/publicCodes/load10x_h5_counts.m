function [X, geneInfo, barcodes] = load10x_h5_counts(h5file)
% Load 10x Genomics H5 matrix.
%
% Outputs:
%   X        : spots/cells x genes
%   geneInfo : table with gene IDs, symbols, and feature type
%   barcodes : spot/cell barcodes

data    = h5read(h5file, '/matrix/data');
indices = h5read(h5file, '/matrix/indices');
indptr  = h5read(h5file, '/matrix/indptr');
shape   = h5read(h5file, '/matrix/shape');

barcodes = string(h5read(h5file, '/matrix/barcodes'));

geneID = string(h5read(h5file, '/matrix/features/id'));

try
    geneSymbol = string(h5read(h5file, '/matrix/features/name'));
catch
    geneSymbol = geneID;
end

try
    featureType = string(h5read(h5file, '/matrix/features/feature_type'));
catch
    featureType = repmat("Gene Expression", numel(geneID), 1);
end

nGenes = double(shape(1));
nCells = double(shape(2));

rows = double(indices) + 1;
cols = zeros(numel(data),1);

for c = 1:nCells
    startIdx = double(indptr(c)) + 1;
    endIdx   = double(indptr(c+1));
    cols(startIdx:endIdx) = c;
end

M = sparse(rows, cols, double(data), nGenes, nCells);
X = full(M');   % spots/cells x genes

geneInfo = table(geneID, geneSymbol, featureType, ...
    'VariableNames', {'GeneID','GeneSymbol','FeatureType'});

end