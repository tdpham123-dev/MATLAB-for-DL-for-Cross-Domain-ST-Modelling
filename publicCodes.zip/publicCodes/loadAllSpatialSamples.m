function [X, S, labels, domains, geneLists, sampleNames] = loadAllSpatialSamples(samples)

X = {};
S = {};
labels = {};
domains = {};
geneLists = {};
sampleNames = strings(0,1);

count = 0;

for i = 1:numel(samples)

    fprintf('Loading spatial sample %d/%d: %s\n', i, numel(samples), samples(i).id);

    [Xi, genesI, barcodesI] = load10x_h5_counts(samples(i).h5);
    [Si, keepIdx] = loadVisiumPositions(samples(i), barcodesI);

    if isempty(Si) || isempty(keepIdx)
        fprintf('Skipping sample without usable spatial coordinates: %s\n', samples(i).id);
        continue;
    end

    Xi = Xi(keepIdx,:);

    count = count + 1;

    X{count,1} = Xi;
    S{count,1} = Si;
    labels{count,1} = samples(i).label * ones(size(Xi,1),1);
    domains{count,1} = samples(i).domain * ones(size(Xi,1),1);
    geneLists{count,1} = genesI;
    sampleNames(count,1) = samples(i).id;
end

end