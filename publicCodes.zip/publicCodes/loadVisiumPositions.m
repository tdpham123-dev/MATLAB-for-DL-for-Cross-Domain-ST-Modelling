function [coords, keepIdx] = loadVisiumPositions(sample, barcodes)
% Loads Visium tissue positions and aligns them to expression barcodes.
% Robust to different folder structures inside *_spatial_images.

if strlength(sample.spatialFolder) > 0

    % Search recursively for possible coordinate files
    files1 = dir(fullfile(sample.spatialFolder, '**', 'tissue_positions.csv'));
    files2 = dir(fullfile(sample.spatialFolder, '**', 'tissue_positions_list.csv'));

    if ~isempty(files1)
        posFile = fullfile(files1(1).folder, files1(1).name);
    elseif ~isempty(files2)
        posFile = fullfile(files2(1).folder, files2(1).name);
    else
        warning('No tissue position file found for %s. Skipping sample.', sample.id);
        coords = [];
        keepIdx = [];
        return;
    end

else
    posFile = sample.positions;

    if ~exist(posFile, 'file')
        warning('Position file missing for %s. Skipping sample.', sample.id);
        coords = [];
        keepIdx = [];
        return;
    end
end

T = readtable(posFile, 'FileType', 'text', 'ReadVariableNames', false);

posBarcodes = string(T{:,1});

if width(T) >= 6
    coordsAll = [double(T{:,6}), double(T{:,5})];
elseif width(T) >= 4
    coordsAll = [double(T{:,4}), double(T{:,3})];
else
    warning('Unexpected tissue position format for %s. Skipping sample.', sample.id);
    coords = [];
    keepIdx = [];
    return;
end

[~, idxExpr, idxPos] = intersect(barcodes, posBarcodes, 'stable');

coords = coordsAll(idxPos,:);
keepIdx = idxExpr;

if isempty(coords)
    warning('No matching barcodes for %s. Skipping sample.', sample.id);
    coords = [];
    keepIdx = [];
end

end