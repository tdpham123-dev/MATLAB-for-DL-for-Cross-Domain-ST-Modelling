
%% main_STmodeling.m
% Deep Learning-Driven Cross-Domain Spatial Transcriptomic Modelling
%
% Inputs:
%   Spatial transcriptomics:
%       GSE241124: .h5 + spatial_images folders
%       GSE208253: .h5 + tissue_positions_list.csv + scalefactors_json.json
%       GSE181300: .h5 + tissue_positions_list.csv + scalefactors_json.json
%
%   scRNA-seq:
%       GSE215403: matrix.mtx + features.tsv + barcodes.tsv
%       GSE181919: UMI_counts.txt + Barcode_metadata.txt
%       GSE140042: filtered_feature_bc_matrix.h5 (REMOVED)
%
% Outputs:
%   model_outputs/FullModel_results.mat
%   manuscript_outputs/*.csv
%   manuscript_outputs/*.png

clear; clc; close all;
rng(1);

%% ------------------------------------------------------------------------
% 1. Settings
% -------------------------------------------------------------------------

modeName = "FullModel";

settings.useGraph = true;
settings.useDomainLoss = true;
settings.useContrastiveLoss = false;
settings.useClusteringLoss = true;
settings.useRecurrence = true;
settings.useSSI = false; % default
settings.useCellProjection = true;

numHVG = 1000;

settings.kGraph = 6;
settings.hiddenDim1 = 256;
settings.hiddenDim2 = 128;
settings.latentDim = 64;
settings.numStages = 4;
settings.numDomains = 3;
settings.numClusters = 5;

settings.numEpochs = 100;
settings.learningRate = 1e-3;

settings.lambdaDom = 0.2;
settings.lambdaCon = 0.5;
settings.lambdaClust = 0.5;
settings.lambdaReg = 1e-4;
settings.clusterWarmupEpochs = 20;

settings.outputDir = "model_outputs_corrected";
settings.figureDir = "manuscript_outputs_corrected";

if ~exist(settings.outputDir, 'dir'), mkdir(settings.outputDir); end
if ~exist(settings.figureDir, 'dir'), mkdir(settings.figureDir); end

gtfFile = 'D:\WORK\spatialBiology-Trauma\reference\Homo_sapiens.GRCh38.109.gtf';
if ~isfile(gtfFile)
    error('GTF file not found: %s', gtfFile);
end


if exist('ensembl_to_hgnc_geneMap.mat', 'file')
    load('ensembl_to_hgnc_geneMap.mat', 'geneMap');
else
    gtfFile = 'D:\WORK\spatialBiology-Trauma\reference\Homo_sapiens.GRCh38.109.gtf';
    if ~isfile(gtfFile)
        error('GTF file not found: %s', gtfFile);
    end
    geneMap = buildEnsemblToSymbolMapFromGTF(gtfFile);
end
%%
forceGenesSymbol = [
    "IL1B","TNF","CXCL8","CXCL1","CXCL2","S100A8","S100A9","NFKBIA", ...
    "HIF1A","VEGFA","CA9","LDHA","SLC2A1","ENO1", ...
    "COL1A1","COL1A2","COL3A1","FN1","POSTN","MMP2","MMP9","VIM", ...
    "RUNX2","SP7","ALPL","BGLAP","SPP1","IBSP","BMP2"
];

geneMap.GeneSymbol = upper(strtrim(string(geneMap.GeneSymbol)));
geneMap.EnsemblID  = upper(strtrim(string(geneMap.EnsemblID)));
forceGenesSymbol   = upper(strtrim(forceGenesSymbol));
forceGeneIDs = geneMap.EnsemblID(ismember(geneMap.GeneSymbol, forceGenesSymbol));
fprintf('Forced marker Ensembl IDs found: %d\n', numel(forceGeneIDs));

%% ------------------------------------------------------------------------
% 2. Dataset folders
% -------------------------------------------------------------------------

paths.GSE241124 = ...
'D:\WORK\spatialBiology-Trauma\spatialTranscriptomics\GSE241124\GSE241124_RAW';

paths.GSE208253 = ...
'D:\WORK\spatialBiology-Trauma\spatialTranscriptomics\GSE208253\GSE208253_RAW';

paths.GSE181300 = ...
'D:\WORK\spatialBiology-Trauma\spatialTranscriptomics\GSE181300\GSE181300_RAW';

paths.sc_GSE215403 = ...
'D:\WORK\spatialBiology-Trauma\scRNA\GSE215403\GSE215403_RAW';

paths.sc_GSE181919 = ...
'D:\WORK\spatialBiology-Trauma\scRNA\GSE181919';

paths.sc_GSE140042 = ...
'D:\WORK\spatialBiology-Trauma\scRNA\GSE140042\GSE140042_RAW';

%% ------------------------------------------------------------------------
% 3. Build sample lists
% -------------------------------------------------------------------------

samples1 = buildSamples_GSE241124(paths.GSE241124);
samples2 = buildSamples_GSE208253(paths.GSE208253);
samples3 = buildSamples_GSE181300(paths.GSE181300);

allSamples = [samples1, samples2, samples3];

% Fast debug mode: use small subset first
% allSamples = allSamples(1:min(8,numel(allSamples)));

fprintf('Total spatial samples: %d\n', numel(allSamples));

%% ------------------------------------------------------------------------
% 4. Load spatial transcriptomics data
% -------------------------------------------------------------------------

[X, S, labels, domains, geneLists, sampleNames] = loadAllSpatialSamples(allSamples);

%disp(geneLists{1}(1:20,:))

%% ------------------------------------------------------------------------
% 5. Harmonise common genes
% -------------------------------------------------------------------------

[X, commonGenes] = harmoniseGenes(X, geneLists);

fprintf('Common spatial genes retained: %d\n', numel(commonGenes));

%% Select highly variable genes but force-retain pathway markers


[X, commonGenes] = selectHighlyVariableGenesWithMarkers( ...
    X, commonGenes, numHVG, forceGeneIDs);


fprintf('Highly variable plus marker genes retained: %d\n', numel(commonGenes));



%% Map Ensembl IDs to HGNC symbols for biological scoring

geneSymbolForScoring = mapEnsemblToHGNC(commonGenes, geneMap);

markerCheck = ["IL1B","TNF","CXCL8","COL1A1","VEGFA","RUNX2","ALPL"];
detectedMarkers = intersect(geneSymbolForScoring, markerCheck);

disp('Detected mapped marker genes:')
disp(detectedMarkers)

if numel(detectedMarkers) >= 3
    settings.useSSI = true;
else
    warning('Too few mapped pathway markers detected. Disabling SSI scoring.');
    settings.useSSI = false;
end
%% ------------------------------------------------------------------------
% 6. Normalisation and standardisation
% -------------------------------------------------------------------------

X = normaliseAndStandardise(X, allSamples);

%% ------------------------------------------------------------------------
% 7. Spatial graph construction
% -------------------------------------------------------------------------

fprintf('Starting graph construction...\n');
tic;


Ahat = cell(numel(X),1);

for i = 1:numel(X)
    fprintf('Building graph %d/%d: %s\n', i, numel(X), sampleNames(i));
    if settings.useGraph
        Ahat{i} = buildSpatialGraph(S{i}, settings.kGraph);
    else
        Ahat{i} = [];
    end
end
fprintf('Graph construction completed in %.2f seconds.\n', toc);

%% ------------------------------------------------------------------------
% 8. Initialise model
% -------------------------------------------------------------------------

params = initializeParameters( ...
    numel(commonGenes), ...
    settings.hiddenDim1, ...
    settings.hiddenDim2, ...
    settings.latentDim, ...
    settings.numStages, ...
    settings.numDomains, ...
    settings.numClusters);

%% ------------------------------------------------------------------------
% 9. Train model
% -------------------------------------------------------------------------

[params, trainHistory] = trainModel(params, X, Ahat, labels, domains, settings);

%% ------------------------------------------------------------------------
% 10. Inference
% -------------------------------------------------------------------------

[Z, clusterLabels] = inferEmbeddingsAndClusters(params, X, Ahat, settings);

%% ------------------------------------------------------------------------
% 11. Spatial recurrence, pathway scores and SSI-like score
% -------------------------------------------------------------------------

Rmat = cell(numel(X),1);
localCoherence = cell(numel(X),1);
PFI = nan(numel(X),1);
pathwayScores = cell(numel(X),1);
SSIscore = cell(numel(X),1);

for i = 1:numel(X)

    if settings.useSSI
        pathwayScores{i} = computePathwayScores(X{i}, geneSymbolForScoring);
        SSIscore{i} = computeSSIscore(pathwayScores{i});
    end

    if settings.useRecurrence
        Rmat{i} = recurrenceMatrix(Z{i});
        localCoherence{i} = computeLocalCoherence(Rmat{i}, S{i}, settings.kGraph);

        if settings.useSSI
            pathologicalCluster = identifyPathologicalClusterBySSI(clusterLabels{i}, SSIscore{i});
        else
            pathologicalCluster = mode(clusterLabels{i});
        end

        PFI(i) = computePFI(Rmat{i}, S{i}, clusterLabels{i}, pathologicalCluster, settings.kGraph);
    end
end
%%
SSIclusterTables = cell(numel(X),1);

if settings.useSSI
    for i = 1:numel(X)
        SSIclusterTables{i} = summarizeSSIByCluster( ...
            clusterLabels{i}, SSIscore{i}, sampleNames(i));
    end
end


%% ------------------------------------------------------------------------
% 12. Performance metrics with means and standard deviations
% -------------------------------------------------------------------------

metrics = computeAllMetrics( ...
    params, X, Ahat, labels, domains, Z, clusterLabels, ...
    localCoherence, PFI, SSIscore, settings);


%% ------------------------------------------------------------------------
% 13. scRNA reference construction and cell-state projection
% -------------------------------------------------------------------------

cellProjectionResults = [];

if settings.useCellProjection

    fprintf('Building scRNA reference atlases...\n');

    ref215403 = buildReference_GSE215403(paths.sc_GSE215403);
    ref181919 = buildReference_GSE181919(paths.sc_GSE181919);
    %ref140042 = buildReference_GSE140042(paths.sc_GSE140042);

    %scRefs = {ref215403, ref181919, ref140042};
    %scRefNames = {'GSE215403','GSE181919','GSE140042'};

    scRefs = {ref215403, ref181919};
    scRefNames = {'GSE215403','GSE181919'};

    fprintf('Projecting scRNA cell states onto spatial clusters...\n');

    cellProjectionResults = projectAllCellStates( ...
        scRefs, scRefNames, X, geneSymbolForScoring, ...
        clusterLabels, sampleNames, settings.figureDir);
end

%% ------------------------------------------------------------------------
% 14. Save full results
% -------------------------------------------------------------------------

results.modeName = modeName;
results.settings = settings;
results.params = params;
results.trainHistory = trainHistory;
results.metrics = metrics;
results.Z = Z;
results.clusterLabels = clusterLabels;
results.Rmat = Rmat;
results.localCoherence = localCoherence;
results.PFI = PFI;
results.pathwayScores = pathwayScores;
results.SSIscore = SSIscore;
results.cellProjectionResults = cellProjectionResults;
results.sampleNames = sampleNames;
results.commonGenes = commonGenes;
results.allSamples = allSamples;
results.S = S;
results.SSIclusterTables = SSIclusterTables;
results.geneSymbolForScoring = geneSymbolForScoring;

save(fullfile(settings.outputDir, "FullModel_results.mat"), 'results', '-v7.3');

%% ------------------------------------------------------------------------
% 15. Generate tables and figures for manuscript
% -------------------------------------------------------------------------

%generateManuscriptOutputs(results, settings.figureDir);

generateManuscriptOutputs_improved(results, settings.figureDir);

disp('Full model completed.');

%-----------
disp(results.metrics.classification)
disp(results.metrics.clustering)
disp(results.metrics.domain)
disp(results.metrics.spatial)
disp(results.metrics.biological)

results.cellProjectionResults.referenceName
results.cellProjectionResults.cellTypes
results.cellProjectionResults.Wcell
results.cellProjectionResults.clusterTable

%-------------------------------------------------------------

resultsSmall.modeName = results.modeName;
resultsSmall.metrics = results.metrics;

resultsSmall.clusterLabels = results.clusterLabels;
resultsSmall.PFI = results.PFI;
resultsSmall.localCoherence = results.localCoherence;

resultsSmall.SSIscore = results.SSIscore;
resultsSmall.SSIclusterTables = results.SSIclusterTables;

resultsSmall.cellProjectionResults = results.cellProjectionResults;

resultsSmall.sampleNames = results.sampleNames;
resultsSmall.commonGenes = results.commonGenes;
resultsSmall.geneSymbolForScoring = results.geneSymbolForScoring;

save('resultsSmall.mat','resultsSmall','-v7');
%save(fullfile(settings.outputDir, 'resultsSmall.mat'), ...
%    'resultsSmall', '-v7');

%----------------------------------------------------------------