function T = makeAblationStatistics(allResults, modes)
% Paired statistics comparing FullModel with each ablation.
% Uses paired t-test if normality holds, otherwise Wilcoxon signed-rank.

fullIdx = find(modes == "FullModel", 1);

MetricList = [
    "Silhouette"
    "LocalCoherence"
    "PFI"
    "SSI"
];

Model = strings(0,1);
Metric = strings(0,1);
Test = strings(0,1);
PValue = [];
FullMean = [];
AblationMean = [];
EffectSize = [];

row = 1;

for i = 1:numel(allResults)

    if i == fullIdx
        continue;
    end

    for m = 1:numel(MetricList)

        metricName = MetricList(m);

        x = extractPerSampleMetric(allResults{fullIdx}, metricName);
        y = extractPerSampleMetric(allResults{i}, metricName);

        valid = ~isnan(x) & ~isnan(y);
        x = x(valid);
        y = y(valid);

        if numel(x) < 3
            p = NaN;
            testName = "Insufficient samples";
            effect = NaN;
        else
            diffVals = x - y;

            try
                normalFlag = ~lillietest(diffVals);
            catch
                normalFlag = false;
            end

            if normalFlag
                [~, p] = ttest(x, y);
                testName = "Paired t-test";
            else
                p = signrank(x, y);
                testName = "Wilcoxon signed-rank";
            end

            effect = mean(diffVals, 'omitnan') / (std(diffVals, 'omitnan') + eps);
        end

        Model(row,1) = modes(i);
        Metric(row,1) = metricName;
        Test(row,1) = testName;
        PValue(row,1) = p;
        FullMean(row,1) = mean(x, 'omitnan');
        AblationMean(row,1) = mean(y, 'omitnan');
        EffectSize(row,1) = effect;

        row = row + 1;
    end
end

T = table(Model, Metric, Test, PValue, FullMean, AblationMean, EffectSize);

end