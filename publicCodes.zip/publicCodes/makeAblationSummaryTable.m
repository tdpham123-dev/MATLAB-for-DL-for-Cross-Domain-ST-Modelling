function T = makeAblationSummaryTable(allResults, modes)

n = numel(allResults);

Model = strings(n,1);
Accuracy = strings(n,1);
MacroF1 = strings(n,1);
Sensitivity = strings(n,1);
Specificity = strings(n,1);
Silhouette = strings(n,1);
DomainMixing = strings(n,1);
LocalCoherence = strings(n,1);
PFI = strings(n,1);
SSI = strings(n,1);

for i = 1:n
    r = allResults{i};

    Model(i) = modes(i);

    Accuracy(i) = formatMeanStd(r.metrics.classification.accuracyMean, r.metrics.classification.accuracyStd);
    MacroF1(i) = formatMeanStd(r.metrics.classification.macroF1Mean, r.metrics.classification.macroF1Std);
    Sensitivity(i) = formatMeanStd(r.metrics.classification.sensitivityMean, r.metrics.classification.sensitivityStd);
    Specificity(i) = formatMeanStd(r.metrics.classification.specificityMean, r.metrics.classification.specificityStd);
    Silhouette(i) = formatMeanStd(r.metrics.clustering.silhouetteMean, r.metrics.clustering.silhouetteStd);
    DomainMixing(i) = formatMeanStd(r.metrics.domain.domainMixingMean, r.metrics.domain.domainMixingStd);
    LocalCoherence(i) = formatMeanStd(r.metrics.spatial.localCoherenceMean, r.metrics.spatial.localCoherenceStd);
    PFI(i) = formatMeanStd(r.metrics.spatial.PFIMean, r.metrics.spatial.PFIStd);
    SSI(i) = formatMeanStd(r.metrics.biological.SSIMean, r.metrics.biological.SSIStd);
end

T = table(Model, Accuracy, MacroF1, Sensitivity, Specificity, ...
    Silhouette, DomainMixing, LocalCoherence, PFI, SSI);

end