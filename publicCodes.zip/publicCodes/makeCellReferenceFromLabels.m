function ref = makeCellReferenceFromLabels(X, genes, cellLabels, refName)

genes = upper(strtrim(string(genes)));
cellLabels = upper(strtrim(string(cellLabels)));

valid = genes ~= "" & genes ~= "NA";
X = X(:, valid);
genes = genes(valid);

[genes, ia] = unique(genes, 'stable');
X = X(:, ia);

cellTypes = unique(cellLabels);
cellTypes(cellTypes == "" | cellTypes == "NA") = [];

R = zeros(numel(cellTypes), numel(genes));

Xn = log1p(double(X));

for c = 1:numel(cellTypes)
    idx = cellLabels == cellTypes(c);
    R(c,:) = mean(Xn(idx,:), 1, 'omitnan');
end

ref.name = refName;
ref.genes = genes;
ref.cellTypes = cellTypes;
ref.R = R;

end