function makeCellStateHeatmaps(cellProjectionResults, outDir)
% makeCellStateHeatmaps
% Generates publication-ready heatmaps from cell-state projection results.

if isempty(cellProjectionResults)
    warning('No cell projection results available.');
    return;
end

if ~exist(outDir, 'dir')
    mkdir(outDir);
end

for r = 1:numel(cellProjectionResults)

    if ~isfield(cellProjectionResults(r), 'clusterTable') || isempty(cellProjectionResults(r).clusterTable)
        continue;
    end

    T = cellProjectionResults(r).clusterTable;
    refName = cellProjectionResults(r).referenceName;

    outFile = fullfile(outDir, sprintf('Figure_CellStateHeatmap_%s.png', refName));

    plotCellProjectionHeatmap(T, refName, outFile);
end

end