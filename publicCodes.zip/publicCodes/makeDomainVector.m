function domainVec = makeDomainVector(sampleNames, Z)
% makeDomainVector
% Creates one dataset/domain label per spatial spot for plotting embeddings.
%
% Inputs:
%   sampleNames - string array of sample IDs
%   Z           - cell array of latent embeddings, one matrix per sample
%
% Output:
%   domainVec   - string vector of domain labels, one per spot

domainVec = strings(0,1);

for i = 1:numel(Z)

    n = size(Z{i},1);

    if contains(sampleNames(i), "GSM771") || contains(sampleNames(i), "GSM823")
        d = "GSE241124";
    elseif contains(sampleNames(i), "GSM633")
        d = "GSE208253";
    elseif contains(sampleNames(i), "GSM549")
        d = "GSE181300";
    else
        d = "Unknown";
    end

    domainVec = [domainVec; repmat(d, n, 1)];
end

end