function ref = makeSimpleCellReference(X, genes, refName)

cellLabels = assignBroadCellTypesByMarkers(X, genes);
ref = makeCellReferenceFromLabels(X, genes, cellLabels, refName);

end