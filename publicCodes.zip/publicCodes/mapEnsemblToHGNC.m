function geneSymbols = mapEnsemblToHGNC(ensemblIDs, geneMap)
% Map Ensembl gene IDs to HGNC symbols.
%
% Inputs:
%   ensemblIDs: commonGenes from model, usually ENSG...
%   geneMap: table with EnsemblID and GeneSymbol
%
% Output:
%   geneSymbols: mapped HGNC symbols, same length as ensemblIDs

ensemblIDs = string(ensemblIDs);
ensemblIDs = erase(ensemblIDs, regexp(ensemblIDs, '\.\d+$', 'match', 'once'));

geneMap.EnsemblID = string(geneMap.EnsemblID);
geneMap.GeneSymbol = upper(strtrim(string(geneMap.GeneSymbol)));

geneSymbols = strings(size(ensemblIDs));

[tf, loc] = ismember(ensemblIDs, geneMap.EnsemblID);

geneSymbols(tf) = geneMap.GeneSymbol(loc(tf));
geneSymbols(~tf) = ensemblIDs(~tf);  % fallback

end