function m = meanCellVector(C)
% meanCellVector
% Computes the mean of numeric values stored in a cell array.

vals = [];

if isempty(C)
    m = NaN;
    return;
end

for i = 1:numel(C)
    if ~isempty(C{i})
        vals = [vals; C{i}(:)];
    end
end

if isempty(vals)
    m = NaN;
else
    m = mean(vals, 'omitnan');
end

end