function s = meanGeneSet(X, geneNames, geneSet)
% meanGeneSet
% Returns mean expression of genes in geneSet per spot.

geneSet = upper(string(geneSet));

[~, idx] = intersect(geneNames, geneSet, 'stable');

if isempty(idx)
    warning('No genes found for gene set: %s', strjoin(geneSet, ', '));
    s = zeros(size(X,1),1);
else
    s = mean(X(:,idx), 2, 'omitnan');
end

end