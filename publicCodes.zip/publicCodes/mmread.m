function M = mmread(filename)

fid = fopen(filename, 'r');
if fid < 0
    error('Cannot open %s', filename);
end

line = fgetl(fid);
while startsWith(line, '%')
    line = fgetl(fid);
end

dims = sscanf(line, '%d %d %d');
nRows = dims(1);
nCols = dims(2);
nVals = dims(3);

data = textscan(fid, '%d %d %f', nVals);
fclose(fid);

M = sparse(data{1}, data{2}, data{3}, nRows, nCols);

end