function [loss, gradients, metrics] = modelGradients(params, X, Ahat, labels, domains, ...
    lambdaDom, lambdaCon, lambdaClust, lambdaReg)

Zall = [];
labelAll = [];
domainAll = [];

clsLoss = dlarray(0);

for i = 1:numel(X)

    Z = forwardEncoder(params, X{i}, Ahat{i});
    Zall = [Zall; Z];

    domainAll = [domainAll; domains{i}];

    % Only labelled spots contribute to classification loss
    valid = ~isnan(labels{i});

    if any(valid)
        logits = Z(valid,:) * params.Wc + params.bc;
        clsLoss = clsLoss + crossEntropyLoss(logits, labels{i}(valid) + 1);
        labelAll = [labelAll; labels{i}(valid)];
    end
end

domainLogits = Zall * params.Wd + params.bd;
domLoss = crossEntropyLoss(domainLogits, domainAll);

conLoss = contrastiveLoss(Zall);
clustLoss = clusteringLoss(Zall, params.mu);
regLoss = l2Penalty(params);

loss = clsLoss + ...
       lambdaDom * domLoss + ...
       lambdaCon * conLoss + ...
       lambdaClust * clustLoss + ...
       lambdaReg * regLoss;

gradients = dlgradient(loss, params);

metrics.clsLoss = double(gather(extractdata(clsLoss)));
metrics.domLoss = double(gather(extractdata(domLoss)));
metrics.conLoss = double(gather(extractdata(conLoss)));
metrics.clustLoss = double(gather(extractdata(clustLoss)));
end