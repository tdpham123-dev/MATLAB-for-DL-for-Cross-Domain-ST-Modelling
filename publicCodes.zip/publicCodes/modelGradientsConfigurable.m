function [loss, gradients, metrics] = modelGradientsConfigurable( ...
    params, X, Ahat, labels, domains, settings)

Zall = [];
domainAll = [];

clsLoss = dlarray(0);
domLoss = dlarray(0);
conLoss = dlarray(0);
clustLoss = dlarray(0);

for i = 1:numel(X)

    Z = forwardEncoder(params, X{i}, Ahat{i}, settings);

    Zall = [Zall; Z];
    domainAll = [domainAll; domains{i}];

    valid = ~isnan(labels{i});

    if any(valid)
        logits = Z(valid,:) * params.Wc + params.bc;
        clsLoss = clsLoss + crossEntropyLoss(logits, labels{i}(valid) + 1);
    end
end

if settings.useDomainLoss
    domainLogits = Zall * params.Wd + params.bd;
    domLoss = crossEntropyLoss(domainLogits, domainAll);
end

if settings.useContrastiveLoss
    conLoss = contrastiveLoss(Zall);
end

% DEC clustering is enabled only after warm-up
if settings.useClusteringLoss && ...
        isfield(settings, 'currentEpoch') && ...
        settings.currentEpoch > settings.clusterWarmupEpochs

    clustLoss = clusteringLossDEC(Zall, params.mu);
end

regLoss = l2Penalty(params);

loss = clsLoss ...
    + settings.lambdaDom * domLoss ...
    + settings.lambdaCon * conLoss ...
    + settings.lambdaClust * clustLoss ...
    + settings.lambdaReg * regLoss;

gradients = dlgradient(loss, params);

metrics.clsLoss = double(gather(extractdata(clsLoss)));
metrics.domLoss = double(gather(extractdata(domLoss)));
metrics.conLoss = double(gather(extractdata(conLoss)));
metrics.clustLoss = double(gather(extractdata(clustLoss)));

end