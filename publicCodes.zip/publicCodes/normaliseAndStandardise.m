function Xout = normaliseAndStandardise(X, samples)

Xout = X;

for i = 1:numel(Xout)
    Xout{i} = normalizeCounts(Xout{i});
end

% Training statistics from labelled GSE241124 only
trainIdx = find([samples.domain] == 1 & ~isnan([samples.label]));

Xtrain = cat(1, Xout{trainIdx});

mu = mean(Xtrain,1);
sigma = std(Xtrain,[],1);

for i = 1:numel(Xout)
    Xout{i} = (Xout{i} - mu) ./ (sigma + 1e-8);
end
end