function Xnorm = normalizeCounts(X)

libSize = sum(X,2);
Xnorm = log1p(1e4 * X ./ (libSize + eps));

end