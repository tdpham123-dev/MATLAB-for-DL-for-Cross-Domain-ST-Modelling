function plotCellProjectionHeatmap(T, refName, outFile)

clusters = unique(T.Cluster);
cellTypes = unique(T.CellType, 'stable');

M = nan(numel(clusters), numel(cellTypes));

for i = 1:numel(clusters)
    for j = 1:numel(cellTypes)
        idx = T.Cluster == clusters(i) & T.CellType == cellTypes(j);
        M(i,j) = mean(T.MeanProportion(idx), 'omitnan');
    end
end

fig = figure('Visible','on', 'Color','w', ...
    'Position',[100 100 900 500]);

imagesc(M);
colorbar;

% ---------------------------------------------------------
% Display numerical values within the heatmap cells
% ---------------------------------------------------------
for i = 1:size(M,1)
    for j = 1:size(M,2)
        if ~isnan(M(i,j))
            text(j, i, sprintf('%.2f', M(i,j)), ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                 'FontWeight', 'bold', ...
                'FontSize', 12, 'Color', 'r');
        end
    end
end

xticks(1:numel(cellTypes));
xticklabels(cellTypes);
xtickangle(45);

yticks(1:numel(clusters));
yticklabels("Cluster " + string(clusters));

% title("Cell-state projection: " + refName,'Interpreter','none');


hTitle = title("Cell-state projection: " + refName, ...
    'Interpreter','none');

hTitle.Units = 'normalized';
hTitle.Position(2) = 1.05;

xlabel('Cell state');
ylabel('Spatial cluster');

set(gca, 'FontSize', 12, 'LineWidth', 1);

exportgraphics(fig, outFile, 'Resolution', 300);

%close(fig);

end