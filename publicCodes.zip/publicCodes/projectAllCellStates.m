function results = projectAllCellStates(scRefs, scRefNames, Xst, stGenes, clusterLabels, sampleNames, figureDir)

results = struct();
allTables = cell(numel(scRefs),1);

for r = 1:numel(scRefs)

    ref = scRefs{r};

    fprintf('Projecting reference %s...\n', scRefNames{r});

    [Wcell, cellTypes] = projectCellStatesToSpatial(Xst, stGenes, ref);

    clusterTable = summarizeCellStatesByCluster(Wcell, cellTypes, clusterLabels, sampleNames);

    results(r).referenceName = scRefNames{r};
    results(r).cellTypes = cellTypes;
    results(r).Wcell = Wcell;
    results(r).clusterTable = clusterTable;

    outCsv = fullfile(figureDir, sprintf('CellProjection_%s_cluster_summary.csv', scRefNames{r}));
    writetable(clusterTable, outCsv);

    outFig = fullfile(figureDir, sprintf('Figure_CellProjection_%s_heatmap.png', scRefNames{r}));
    plotCellProjectionHeatmap(clusterTable, scRefNames{r}, outFig);

    allTables{r} = clusterTable;
end

resultsAll = vertcat(allTables{:});
writetable(resultsAll, fullfile(figureDir, 'CellProjection_AllReferences_cluster_summary.csv'));

end