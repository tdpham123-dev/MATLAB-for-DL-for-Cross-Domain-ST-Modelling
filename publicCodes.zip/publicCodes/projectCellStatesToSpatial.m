function [Wcell, cellTypes] = projectCellStatesToSpatial(Xst, stGenes, ref)

stGenes = upper(strtrim(string(stGenes)));
refGenes = upper(strtrim(string(ref.genes)));

[sharedGenes, iaST, iaRef] = intersect(stGenes, refGenes, 'stable');

fprintf('Shared ST-scRNA genes: %d\n', numel(sharedGenes));

if numel(sharedGenes) < 50
    warning('Few shared genes between ST and scRNA reference.');
end

R = ref.R(:, iaRef);
cellTypes = ref.cellTypes;

R = double(R);
R = R ./ (sqrt(sum(R.^2,2)) + eps);

Wcell = cell(size(Xst));

for i = 1:numel(Xst)

    X = double(Xst{i}(:, iaST));
    X = X ./ (sqrt(sum(X.^2,2)) + eps);

    S = X * R';

    S(S < 0) = 0;

    W = S ./ (sum(S,2) + eps);

    Wcell{i} = W;
end

end