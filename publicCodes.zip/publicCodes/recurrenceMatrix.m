function R = recurrenceMatrix(Z)
% recurrenceMatrix
% Computes Gaussian-kernel recurrence matrix from latent embeddings.
%
% Input:
%   Z - spots x latent dimensions
%
% Output:
%   R - spots x spots recurrence/similarity matrix

D = squareform(pdist(Z, 'euclidean'));

nonzeroD = D(D > 0);

if isempty(nonzeroD)
    sigmaR = 1;
else
    sigmaR = median(nonzeroD);
end

R = exp(-(D.^2) ./ (sigmaR^2 + eps));

end