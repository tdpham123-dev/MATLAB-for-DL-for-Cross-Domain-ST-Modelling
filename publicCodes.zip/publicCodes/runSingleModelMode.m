function results = runSingleModelMode(modeName)
% runSingleModelMode
% Runs the model under one ablation condition.
%
% Input:
%   modeName:
%       "FullModel"
%       "NoGraph"
%       "NoDomainLoss"
%       "NoContrastiveLoss"
%       "NoClusteringLoss"
%       "NoRecurrence"
%       "NoSSI"
%
% Output:
%   results structure

settings.useGraph = true;
settings.useDomainLoss = true;
settings.useContrastiveLoss = true;
settings.useClusteringLoss = true;
settings.useRecurrence = true;
settings.useSSI = true;
settings.useCellProjection = false;   % disabled in ablation for speed

switch modeName
    case "FullModel"
    case "NoGraph"
        settings.useGraph = false;
    case "NoDomainLoss"
        settings.useDomainLoss = false;
    case "NoContrastiveLoss"
        settings.useContrastiveLoss = false;
    case "NoClusteringLoss"
        settings.useClusteringLoss = false;
    case "NoRecurrence"
        settings.useRecurrence = false;
    case "NoSSI"
        settings.useSSI = false;
    otherwise
        error('Unknown ablation mode.');
end

settings.kGraph = 6;
settings.hiddenDim1 = 256;
settings.hiddenDim2 = 128;
settings.latentDim = 64;
settings.numStages = 4;
settings.numDomains = 3;
settings.numClusters = 5;

settings.numEpochs = 100;
settings.learningRate = 1e-3;

settings.lambdaDom = 0.2;
settings.lambdaCon = 0.5;
settings.lambdaClust = 0.1;
settings.lambdaReg = 1e-4;

settings.outputDir = "model_outputs";

if ~exist(settings.outputDir, 'dir'), mkdir(settings.outputDir); end

paths.GSE241124 = ...
'D:\WORK\spatialBiology-Trauma\spatialTranscriptomics\GSE241124\GSE241124_RAW';

paths.GSE208253 = ...
'D:\WORK\spatialBiology-Trauma\spatialTranscriptomics\GSE208253\GSE208253_RAW';

paths.GSE181300 = ...
'D:\WORK\spatialBiology-Trauma\spatialTranscriptomics\GSE181300\GSE181300_RAW';

samples1 = buildSamples_GSE241124(paths.GSE241124);
samples2 = buildSamples_GSE208253(paths.GSE208253);
samples3 = buildSamples_GSE181300(paths.GSE181300);

allSamples = [samples1, samples2, samples3];

[X, S, labels, domains, geneLists, sampleNames] = loadAllSpatialSamples(allSamples);
[X, commonGenes] = harmoniseGenes(X, geneLists);
X = normaliseAndStandardise(X, allSamples);

Ahat = cell(numel(X),1);
for i = 1:numel(X)
    if settings.useGraph
        Ahat{i} = buildSpatialGraph(S{i}, settings.kGraph);
    else
        Ahat{i} = [];
    end
end

params = initializeParameters( ...
    numel(commonGenes), ...
    settings.hiddenDim1, ...
    settings.hiddenDim2, ...
    settings.latentDim, ...
    settings.numStages, ...
    settings.numDomains, ...
    settings.numClusters);

[params, trainHistory] = trainModel(params, X, Ahat, labels, domains, settings);

[Z, clusterLabels] = inferEmbeddingsAndClusters(params, X, Ahat, settings);

Rmat = cell(numel(X),1);
localCoherence = cell(numel(X),1);
PFI = nan(numel(X),1);
pathwayScores = cell(numel(X),1);
SSIscore = cell(numel(X),1);

for i = 1:numel(X)

    if settings.useSSI
        pathwayScores{i} = computePathwayScores(X{i}, commonGenes);
        SSIscore{i} = computeSSIscore(pathwayScores{i});
    end

    if settings.useRecurrence
        Rmat{i} = recurrenceMatrix(Z{i});
        localCoherence{i} = computeLocalCoherence(Rmat{i}, S{i}, settings.kGraph);

        if settings.useSSI
            pathologicalCluster = identifyPathologicalClusterBySSI(clusterLabels{i}, SSIscore{i});
        else
            pathologicalCluster = mode(clusterLabels{i});
        end

        PFI(i) = computePFI(Rmat{i}, S{i}, clusterLabels{i}, pathologicalCluster, settings.kGraph);
    end
end

metrics = computeAllMetrics( ...
    params, X, Ahat, labels, domains, Z, clusterLabels, ...
    localCoherence, PFI, SSIscore, settings);

results.modeName = modeName;
results.settings = settings;
results.params = params;
results.trainHistory = trainHistory;
results.metrics = metrics;
results.Z = Z;
results.clusterLabels = clusterLabels;
results.Rmat = Rmat;
results.localCoherence = localCoherence;
results.PFI = PFI;
results.pathwayScores = pathwayScores;
results.SSIscore = SSIscore;
results.sampleNames = sampleNames;
results.commonGenes = commonGenes;
results.allSamples = allSamples;
results.S = S;

save(fullfile(settings.outputDir, modeName + "_results.mat"), 'results', '-v7.3');

end