%% run_ablation_studies.m
% Runs full model and ablation models.
% Produces:
%   ablation_summary.csv
%   ablation_statistics.csv
%   ablation_results.mat

clear; clc; close all;
rng(1);

modes = [
    "FullModel"
    "NoGraph"
    "NoDomainLoss"
    "NoContrastiveLoss"
    "NoClusteringLoss"
    "NoRecurrence"
    "NoSSI"
];

allResults = cell(numel(modes),1);

for m = 1:numel(modes)

    fprintf('\n============================================\n');
    fprintf('Running ablation mode: %s\n', modes(m));
    fprintf('============================================\n');

    allResults{m} = runSingleModelMode(modes(m));
end

save('ablation_results.mat', 'allResults', 'modes', '-v7.3');

Tsummary = makeAblationSummaryTable(allResults, modes);
writetable(Tsummary, 'ablation_summary.csv');

Tstats = makeAblationStatistics(allResults, modes);
writetable(Tstats, 'ablation_statistics.csv');

disp('Ablation studies completed.');