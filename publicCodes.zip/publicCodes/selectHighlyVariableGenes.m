function [Xout, selectedGenes] = selectHighlyVariableGenes(X, geneNames, numHVG)
% Select highly variable genes across all spatial samples.

Xall = cat(1, X{:});

% Basic log-normalisation before variance estimation
libSize = sum(Xall,2);
Xnorm = log1p(1e4 * Xall ./ (libSize + eps));

geneVar = var(Xnorm, 0, 1, 'omitnan');

[~, idx] = sort(geneVar, 'descend');
idx = idx(1:min(numHVG, numel(idx)));

selectedGenes = geneNames(idx);

Xout = cell(size(X));
for i = 1:numel(X)
    Xout{i} = X{i}(:, idx);
end
end