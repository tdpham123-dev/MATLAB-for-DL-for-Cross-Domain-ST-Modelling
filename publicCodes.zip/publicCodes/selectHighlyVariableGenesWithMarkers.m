function [Xout, selectedGenes] = selectHighlyVariableGenesWithMarkers(X, geneNames, numHVG, forceGenes)

geneNames = upper(string(geneNames));
forceGenes = upper(string(forceGenes));

Xall = cat(1, X{:});

libSize = sum(Xall,2);
Xnorm = log1p(1e4 * Xall ./ (libSize + eps));

geneVar = var(Xnorm, 0, 1, 'omitnan');

[~, idxHVG] = sort(geneVar, 'descend');
idxHVG = idxHVG(1:min(numHVG, numel(idxHVG)));

[~, idxForce] = intersect(geneNames, forceGenes, 'stable');

idx = unique([idxHVG(:); idxForce(:)], 'stable');

selectedGenes = geneNames(idx);

Xout = cell(size(X));
for i = 1:numel(X)
    Xout{i} = X{i}(:, idx);
end

fprintf('Forced pathway markers retained: %d\n', numel(idxForce));
if numel(idxForce) < numel(forceGenes)
    missing = setdiff(forceGenes, geneNames);
    fprintf('Missing forced markers from commonGenes: %s\n', strjoin(missing, ', '));
end

end