function s = stdCellVector(C)
% stdCellVector
% Computes the standard deviation of numeric values stored in a cell array.

vals = [];

if isempty(C)
    s = NaN;
    return;
end

for i = 1:numel(C)
    if ~isempty(C{i})
        vals = [vals; C{i}(:)];
    end
end

if isempty(vals)
    s = NaN;
else
    s = std(vals, 'omitnan');
end

end