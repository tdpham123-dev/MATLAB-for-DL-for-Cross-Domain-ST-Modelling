function T = summarizeCellStatesByCluster(Wcell, cellTypes, clusterLabels, sampleNames)

Sample = strings(0,1);
Cluster = [];
CellType = strings(0,1);
MeanProportion = [];
StdProportion = [];
NumSpots = [];

for i = 1:numel(Wcell)

    W = Wcell{i};
    labels = clusterLabels{i};
    clusters = unique(labels);

    for c = 1:numel(clusters)
        idx = labels == clusters(c);

        for t = 1:numel(cellTypes)
            Sample(end+1,1) = sampleNames(i);
            Cluster(end+1,1) = clusters(c);
            CellType(end+1,1) = cellTypes(t);
            MeanProportion(end+1,1) = mean(W(idx,t), 'omitnan');
            StdProportion(end+1,1) = std(W(idx,t), 'omitnan');
            NumSpots(end+1,1) = sum(idx);
        end
    end
end

T = table(Sample, Cluster, CellType, MeanProportion, StdProportion, NumSpots);

end