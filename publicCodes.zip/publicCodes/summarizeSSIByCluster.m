function T = summarizeSSIByCluster(clusterLabels, SSIscore, sampleName)

clusters = unique(clusterLabels);

Cluster = [];
MeanSSI = [];
StdSSI = [];
NumSpots = [];
Sample = strings(numel(clusters),1);

for k = 1:numel(clusters)
    idx = clusterLabels == clusters(k);

    Cluster(k,1) = clusters(k);
    MeanSSI(k,1) = mean(SSIscore(idx), 'omitnan');
    StdSSI(k,1) = std(SSIscore(idx), 'omitnan');
    NumSpots(k,1) = sum(idx);
    Sample(k,1) = sampleName;
end

T = table(Sample, Cluster, MeanSSI, StdSSI, NumSpots);

end