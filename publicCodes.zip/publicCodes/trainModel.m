function [params, trainHistory] = trainModel(params, X, Ahat, labels, domains, settings)

trailingAvg = [];
trailingAvgSq = [];

trainHistory.totalLoss = zeros(settings.numEpochs,1);
trainHistory.clsLoss = zeros(settings.numEpochs,1);
trainHistory.domLoss = zeros(settings.numEpochs,1);
trainHistory.conLoss = zeros(settings.numEpochs,1);
trainHistory.clustLoss = zeros(settings.numEpochs,1);

for epoch = 1:settings.numEpochs

    % Initialise centroids after warm-up
    if epoch == settings.clusterWarmupEpochs + 1 && settings.useClusteringLoss
        fprintf('Initialising DEC centroids using k-means...\n');

        Zall = [];

        for i = 1:numel(X)
            Zi = forwardEncoder(params, X{i}, Ahat{i}, settings);
            Zall = [Zall; gather(extractdata(Zi))];
        end

      

        [~, mu] = kmeans(Zall, settings.numClusters, ...
        'Replicates', 3, ...
        'MaxIter', 300, ...
        'Display', 'off');

        params.mu = dlarray(single(mu));
    end

    settings.currentEpoch = epoch;

    [loss, gradients, metrics] = dlfeval(@modelGradientsConfigurable, ...
        params, X, Ahat, labels, domains, settings);

    [params, trailingAvg, trailingAvgSq] = adamupdate(params, gradients, ...
        trailingAvg, trailingAvgSq, epoch, settings.learningRate);

    trainHistory.totalLoss(epoch) = double(gather(extractdata(loss)));
    trainHistory.clsLoss(epoch) = metrics.clsLoss;
    trainHistory.domLoss(epoch) = metrics.domLoss;
    trainHistory.conLoss(epoch) = metrics.conLoss;
    trainHistory.clustLoss(epoch) = metrics.clustLoss;

    fprintf(['Epoch %03d | Total %.4f | Cls %.4f | Dom %.4f | ', ...
             'Con %.4f | Clust %.4f\n'], ...
        epoch, trainHistory.totalLoss(epoch), ...
        metrics.clsLoss, metrics.domLoss, ...
        metrics.conLoss, metrics.clustLoss);
end

end