function z = zscoreSafe(x)

x = double(x(:));
mu = mean(x, 'omitnan');
sigma = std(x, 'omitnan');

if sigma < eps
    z = zeros(size(x));
else
    z = (x - mu) ./ sigma;
end

end